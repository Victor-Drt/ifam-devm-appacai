package com.ifam.devm.appacai.utils.MaskCopy

/**
 * Created by fatih.santalu on 7/7/2020.
 */

internal enum class Action {
    INSERT,
    DELETE
}