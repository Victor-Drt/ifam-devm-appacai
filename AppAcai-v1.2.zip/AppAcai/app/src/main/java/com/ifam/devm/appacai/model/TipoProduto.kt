package com.ifam.devm.appacai.model

enum class TipoProduto {
    PRINCIPAL,
    FRUTAS,
    COMPLEMENTOS,
    CALDAS
}